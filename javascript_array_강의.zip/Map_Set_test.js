
console.log("==================== Map =====================");
let map = new Map();

map.set('1', 'str1');   // 문자형 키
map.set(1, 'num1');     // 숫자형 키
map.set(true, 'bool1'); // 불린형 키

/* 객체는 키를 문자형으로 변환, 맵은 키의 타입을 변환시키지 않고 그대로 유지 */
console.log( map.get(1)   ); // 'num1'
console.log( map.get('1') ); // 'str1'
console.log( map.size ); // 3

let recipeMap = new Map([
  ['cucumber', 500],
  ['tomatoes', 350],
  ['onion',    50]
]);

// 키(vegetable)를 대상으로 순회합니다.
for (let vegetable of recipeMap.keys()) {
  console.log("key:", vegetable); // cucumber, tomatoes, onion
}

// 값(amount)을 대상으로 순회합니다.
for (let amount of recipeMap.values()) {
  console.log("value:", amount); // 500, 350, 50
}

// [키, 값] 쌍을 대상으로 순회합니다.
for (let entry of recipeMap) { // recipeMap.entries()와 동일합니다.
  console.log(`key:${entry[0]} , value:${entry[1]}, entry:${entry}`);

}

/* foreach 구분도 지원 */
recipeMap.forEach( (value, key, map) => {
  console.log(`map.foreach : ${key}: ${value}`); 
});


let obj = Object.fromEntries(recipeMap.entries()); 
console.log("map을 객체로 변환 Object.fromEntries(recipeMap.entries()) : ", obj); 

let recipeMapFromObj = new Map(Object.entries(obj));
console.log("객체를 맵으로 변환 new Map(Object.entries(obj)) : ", recipeMapFromObj); 
console.log("recipeMapFromObj.get('tomatoes'):", recipeMapFromObj.get('tomatoes') ); // 'str1'
console.log("recipeMapFromObj.size :", recipeMapFromObj.size ); // 3


console.log("==================== Set =====================");
let set = new Set();

let john = { name: "John" };
let pete = { name: "Pete" };
let mary = { name: "Mary" };
let maryNot = { name: "Mary" };


set.add(john);
set.add(pete);
set.add(mary);
set.add(john);
set.add(mary);


console.log("set.has(mery):" , set.has(mary));
console.log("set.has(maryNot):" , set.has(maryNot));

// 셋(Set)은 중복을 허용 않음.  
console.log("set.size:" ,  set.size); // 3

for (let user of set) {
  console.log(user.name); // // John, Pete, Mary 순으로 출력됩니다.
}


// forEach를 사용해도 동일하게 동작합니다.
set.forEach((value, valueAgain, set) => {
  console.log('set.foreach', value, ":", valueAgain);
});